from iphack.iphack import ip
from iphack.iphack import inquiry
