from iphack.iphack import ip
from iphack.iphack import inquiry
from iphack.iphack import check
